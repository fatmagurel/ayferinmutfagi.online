<div class="header-middle"><!--header-middle-->
				<hr>
			<marquee  style="color:black"><b>SADECE KÜTAHYA İÇİ SERVİS YAPILIR... KAPIDA ÖDEME YAPILMAKTADIR... BİZİ 05428336352 BU NUMARADAN ARAYARAK SİPARİŞ VEREBİLİRSİNİZ...</b></marquee>
		<hr>
		</div>
    <section class="ftco-section" id="yemekler">
	<div class="container">
		<div class="row no-gutters ftco-services">
          <div class="col-md-3 text-center d-flex align-self-stretch ftco-animate">
            <div class="media block-6 services mb-md-0 mb-4">
              <div class="icon bg-color-2 d-flex justify-content-center align-items-center mb-2">
            		<span class="flaticon-diet"></span>
              </div>
              <div class="media-body">
                <h3 class="heading">HER ZAMAN TAZE</h3>
                <span>GÜNLÜK ÜRETİM</span>
              </div>
            </div>    
          </div>
          <div class="col-md-3 text-center d-flex align-self-stretch ftco-animate">
            <div class="media block-6 services mb-md-0 mb-4">
              <div class="icon bg-color-3 d-flex justify-content-center align-items-center mb-2">
            		<span class="flaticon-award"></span>
              </div>
              <div class="media-body">
                <h3 class="heading">ÜSTÜN KALİTE</h3>
                <span>KALİTELİ ÜRÜNLER</span>
              </div>
            </div>      
          </div>
          <div class="col-md-3 text-center d-flex align-self-stretch ftco-animate">
            <div class="media block-6 services mb-md-0 mb-4">
              <div class="icon bg-color-4 d-flex justify-content-center align-items-center mb-2">
            		<span class="flaticon-customer-service"></span>
              </div>
              <div class="media-body">
                <h3 class="heading">TESLİMAT SAATLERİ</h3>
                <span>7.00-00.00 </span>
              </div>
            </div>      
          </div>
		  <div class="col-md-3 text-center d-flex align-self-stretch ftco-animate">
            <div class="media block-6 services mb-md-0 mb-4">
              <div class="icon bg-color-1 active d-flex justify-content-center align-items-center mb-2">
            		<span class="flaticon-shipped"></span>
              </div>
              <div class="media-body">
                <h3 class="heading">SERVİSİMİZ MEVCUTTUR</h3>
                <span>SADECE KÜTAHYA İÇİ SERVİS YAPILIR</span>
              </div>
            </div>      
          </div>
        </div>
	</div>
	
		</section>

		<section class="ftco-section ftco-category ftco-no-pt" >
			<div class="container">
				<div class="row">
					<div class="col-md-8" >
						<div class="row">
							<div class="col-md-6 order-md-last align-items-stretch d-flex">
								<div class="category-wrap-2 ftco-animate img align-self-stretch d-flex" style="background-image: url(assets/images/background.png);">
									<div class="text text-center">
										<h2>Ürünler</h2>
										
										<p><a href="#urun" class="btn btn-primary active">Alışverişe Başla</a></p>
									</div>
								</div>
							</div>
							
							<div class="col-md-6">
								<div class="category-wrap ftco-animate img mb-4 d-flex align-items-end" style="background-image: url(assets/images/tuzlukurabiye.jpg);">
									<div class="text px-3 py-1">
										<h2 class="mb-0"><a href="#kurabiyeler">Kurabiyeler</a></h2>
									</div>
								</div>
								<div class="category-wrap ftco-animate img d-flex align-items-end" style="background-image: url(assets/images/baklava.jpg);">
									<div class="text px-3 py-1">
										<h2 class="mb-0"><a href="#tatlilar">Tatlılar</a></h2>
									</div>
								</div>
							</div>
							
						</div>
					</div>
					
					<div class="col-md-4">
						<div class="category-wrap ftco-animate img mb-4 d-flex align-items-end" style="background-image: url(assets/images/pogaca.jpg);">
							<div class="text px-3 py-1">
								<h2 class="mb-0"><a href="#hamur">Hamur İşleri</a></h2>
							</div>		
						</div>
						<div class="category-wrap ftco-animate img d-flex align-items-end" style="background-image: url(assets/images/iclikofte.jpg);">
							<div class="text px-3 py-1">
								<h2 class="mb-0" id="kurabiyeler"><a href="#ana">Ana ve Yardımcı Yemekler</a></h2>
							</div>
						</div>
					</div>
					
				</div>
			</div>
		</section>
	
<section class="ftco-section" id="urun" >
    	<div class="container">
				<div class="row justify-content-center ">
    				<ul class="product-category">
    					<center>
    					<li><a href="#kurabiyeler" >KURABİYELER</a></li>
    					<li><a href="#tatlilar" >TATLILAR</a></li>
    					<li><a href="#hamur" >HAMUR İŞLERİ</a></li>
    					<li><a href="#ana" >ANA VE YARDIMCI YEMEKLER</a></li>
    					</center>
    				</ul>
    			</div>
				<br><br>
    			<div class="row justify-content-center">
    				<ul class="product-category">
    					<li><a href="#kurabiyeler">KURABİYELER</a></li>
    					
    				</ul>
    			</div>
				
			<div class="container" id="tatlilar">
    		<div class="row justify-content-center" >
    			<div class="col-md-6 col-lg-3 ftco-animate">
    				<div class="product" >
    					<a class="img-prod"></img>
						<img class="img-fluid" src="uploads/tatlikur.jpg" alt="Colorlib Template">
    						<div class="overlay"></div>
    					<div class="text py-3 pb-4 px-3 text-center">
    						<h3>TATLI KURABİYE</h3>
    						<div class="d-flex">
    							<div class="pricing">
		    						<p class="price"><span class="price-sale">1 kg 40₺</span></p>
		    					</div>
	    					</div>
	    					<div class="bottom-area d-flex px-3">
	    						<div class="m-auto d-flex">
	    							
    							</div>
    						</div>
    					</div>
    				</div>
				</div>
				
				<div class="col-md-6 col-lg-3 ftco-animate" id="tatlilar">	
					<div class="product">
						<a class="img-prod"></img>
    					<img class="img-fluid" src="uploads/tuzlukurabiye.jpg" alt="Colorlib Template">
    						<div class="overlay"></div>
    					<div class="text py-3 pb-4 px-3 text-center">
    						<h3>TUZLU KURABİYE</h3>
    						<div class="d-flex">
    							<div class="pricing">
		    						<p class="price"><span class="price-sale">1 kg 40₺</span></p>
		    					</div>
	    					</div>
	    					<div class="bottom-area d-flex px-3">
	    						<div class="m-auto d-flex">
	    							
    							</div>
    						</div>
    					</div>
    				</div>
				</div>
    			</div>
				</div>
				
				<div class="row justify-content-center" >
    				<ul class="product-category">
    					
    					<li><a href="#tatlilar" >TATLILAR</a></li>
    					
    				</ul>
    			</div>
				
				<div class="container" >
				<div class="row justify-content-center">
					<div class="col-md-6 col-lg-3 ftco-animate">
						<div class="product">
							<a class="img-prod"><img class="img-fluid" src="uploads/baklava.png" alt="Colorlib Template">
								
								<div class="overlay"></div>
							</a>
							<div class="text py-3 pb-4 px-3 text-center">
								<h3>CEVİZLİ BAKLAVA</h3>
								<div class="d-flex">
									<div class="pricing">
										<p class="price"><span class="price-sale">1 kg 50TL - 1 tepsi 150₺</span></p>
									</div>
								</div>
								<div class="bottom-area d-flex px-3">
									<div class="m-auto d-flex">
										
									</div>
								</div>
							</div>
						</div>
					</div>
					
					<div class="col-md-6 col-lg-3 ftco-animate">	
					<div class="product">
    					<a class="img-prod"><img class="img-fluid" src="uploads/sekerpare.jpg" alt="Colorlib Template">
    						
    						<div class="overlay"></div>
    					</a>
    					<div class="text py-3 pb-4 px-3 text-center">
    						<h3>ŞEKERPARE</h3>
    						<div class="d-flex">
    							<div class="pricing">
		    						<p class="price"><span class="price-sale">1 kg 25₺<br>4 Tanesi 2₺</span></p>
		    					</div>
	    					</div>
	    					<div class="bottom-area d-flex px-3">
	    						<div class="m-auto d-flex">
	    							
    							</div>
    						</div>
    					</div>
    				</div>
					</div>
					
					<div class="col-md-6 col-lg-3 ftco-animate" id="hamur">	
					<div class="product">
    					<a class="img-prod"><img class="img-fluid" src="uploads/revani.jpg" alt="Colorlib Template">
    						
    						<div class="overlay"></div>
    					</a>
    					<div class="text py-3 pb-4 px-3 text-center">
    						<h3>REVANİ</h3>
    						<div class="d-flex">
    							<div class="pricing">
		    						<p class="price"><span class="price-sale">1 kg 30₺<br>1 Porsiyon 2,5₺</span></p>
		    					</div>
	    					</div>
	    					<div class="bottom-area d-flex px-3">
	    						<div class="m-auto d-flex">
	    							
    							</div>
    						</div>
    					</div>
    				</div>
					</div>
    			</div>
				</div>
				
				
				<div class="row justify-content-center">
    				<ul class="product-category">
    					
    					<li><a href="#hamur" >HAMUR İŞLERİ</a></li>
    					
    				</ul>
    			</div>
				
				<div class="container">
				<div class="row justify-content-center" >
    			<div class="col-md-6 col-lg-3 ftco-animate">
    				<div class="product">
    					<a class="img-prod"><img class="img-fluid" src="uploads/suboregi.jpg" alt="Colorlib Template">
    						
    						<div class="overlay"></div>
    					</a>
    					<div class="text py-3 pb-4 px-3 text-center">
    						<h3>SU BÖREĞİ</h3>
    						<div class="d-flex">
    							<div class="pricing">
		    						<p class="price"><span class="price-sale">1 Tepsi(3 kg) 90₺<br>1 Porsiyon 15₺ (Dilim Porsiyonu Büyüktür)</span></p>
		    					</div>
	    					</div>
	    					<div class="bottom-area d-flex px-3">
	    						<div class="m-auto d-flex">
	    							
    							</div>
    						</div>
    					</div>
    				</div>
				</div>
					
					<div class="col-md-6 col-lg-3 ftco-animate">	
					<div class="product">
    					<a class="img-prod"><img class="img-fluid" src="uploads/borek.jpg" alt="Colorlib Template">
    						
    						<div class="overlay"></div>
    					</a>
    					<div class="text py-3 pb-4 px-3 text-center">
    						<h3>BÖREK(MERCİMEKLİ-PATATESLİ)</h3>
    						<div class="d-flex">
    							<div class="pricing">
		    						<p class="price"><span class="price-sale">1 kg 35₺<br>Tanesi 1₺</span></p>
		    					</div>
	    					</div>
	    					<div class="bottom-area d-flex px-3">
	    						<div class="m-auto d-flex">
	    							
    							</div>
    						</div>
    					</div>
    				</div>
					</div>
					
					
					<div class="col-md-6 col-lg-3 ftco-animate">	
					<div class="product">
    					<a class="img-prod"><img class="img-fluid" src="uploads/bukme.jpg" alt="Colorlib Template">
    						
    						<div class="overlay"></div>
    					</a>
    					<div class="text py-3 pb-4 px-3 text-center">
    						<h3>MERCİMEKLİ BÜKME</h3>
    						<div class="d-flex">
    							<div class="pricing">
		    						<p class="price"><span class="price-sale">1 kg 35₺<br>Tanesi 1₺</span></p>
		    					</div>
	    					</div>
	    					<div class="bottom-area d-flex px-3">
	    						<div class="m-auto d-flex">
	    							
    							</div>
    						</div>
    					</div>
    				</div>
					</div>
					
					<div class="col-md-6 col-lg-3 ftco-animate" id="ana">	
					<div class="product">
    					<a class="img-prod"><img class="img-fluid" src="uploads/pogaca.jpg" alt="Colorlib Template">
    						
    						<div class="overlay"></div>
    					</a>
    					<div class="text py-3 pb-4 px-3 text-center">
    						<h3>POĞAÇA(PEYNİRLİ-PATATESLİ)</h3>
    						<div class="d-flex">
    							<div class="pricing">
		    						<p class="price"><span class="price-sale">1 kg 35₺<br>Tanesi 1,5₺</span></p>
		    					</div>
	    					</div>
	    					<div class="bottom-area d-flex px-3">
	    						<div class="m-auto d-flex">
	    							
    							</div>
    						</div>
    					</div>
    				</div>
					</div>
					
    			</div>
				</div>
				
				<div class="row justify-content-center">
    				<ul class="product-category">
    					
    					<li><a href="#ana">ANA VE YARDIMCI YEMEKLER</a></li>
    				</ul>
    			</div>
				
				<div class="container">
				<div class="row justify-content-center" >
    			<div class="col-md-6 col-lg-3 ftco-animate">
    				<div class="product">
    					<a class="img-prod"><img class="img-fluid" src="uploads/iclikofte.jpg" alt="Colorlib Template">
    						
    						<div class="overlay"></div>
    					</a>
    					<div class="text py-3 pb-4 px-3 text-center">
    						<h3>İÇLİ KÖFTE</a></h3>
    						<div class="d-flex">
    							<div class="pricing">
		    						<p class="price"><span class="price-sale">3 Tanesi 10TL</span></p>
		    					</div>
	    					</div>
	    					<div class="bottom-area d-flex px-3">
	    						<div class="m-auto d-flex">
	    							
    							</div>
    						</div>
    					</div>
    				</div>
					</div>
					
					<div class="col-md-6 col-lg-3 ftco-animate">	
					<div class="product">
    					<a class="img-prod"><img class="img-fluid" src="uploads/yaprak.jpg" alt="Colorlib Template">
    						
    						<div class="overlay"></div>
    					</a>
    					<div class="text py-3 pb-4 px-3 text-center">
    						<h3>YAPRAK SARMASI</a></h3>
    						<div class="d-flex">
    							<div class="pricing">
		    						<p class="price"><span class="price-sale">1 kg 50₺<br>1 Porsiyon 12,5₺(20 Adet)</span></p>
		    					</div>
	    					</div>
	    					<div class="bottom-area d-flex px-3">
	    						<div class="m-auto d-flex">
	    							
    							</div>
    						</div>
    					</div>
    				</div>
					</div>
					
					<div class="col-md-6 col-lg-3 ftco-animate">	
					<div class="product">
    					<a class="img-prod"><img class="img-fluid" src="uploads/cimcik.jpg" alt="Colorlib Template">
    						
    						<div class="overlay"></div>
    					</a>
    					<div class="text py-3 pb-4 px-3 text-center">
    						<h3>CİMCİK</a></h3>
    						<div class="d-flex">
    							<div class="pricing">
		    						<p class="price"><span class="price-sale">1 kg 20TL(PİŞMEMİŞ)</span></p>
		    					</div>
	    					</div>
	    					<div class="bottom-area d-flex px-3">
	    						<div class="m-auto d-flex">
	    							
    							</div>
    						</div>
    					</div>
    				</div>
					</div>
					
					<div class="col-md-6 col-lg-3 ftco-animate">	
					<div class="product">
    					<a class="img-prod"><img class="img-fluid" src="uploads/manti.jpg" alt="Colorlib Template">
    						
    						<div class="overlay"></div>
    					</a>
    					<div class="text py-3 pb-4 px-3 text-center">
    						<h3>MANTI</a></h3>
    						<div class="d-flex">
    							<div class="pricing">
		    						<p class="price"><span class="price-sale">1 kg 40TL(PİŞMEMİŞ)</span></p>
		    					</div>
	    					</div>
	    					<div class="bottom-area d-flex px-3">
	    						<div class="m-auto d-flex">
	    							
    							</div>
    						</div>
    					</div>
    				</div>
					</div>
    			</div>				
				</div>
				
				<hr>
				
				
				<div class="container">
					<ul class="nav nav-tabs" role="tablist">
						<li class="nav-item">
							<a class="nav-link active" data-toggle="tab" href="#yorumyap">Yorumunuzu Bizimle Paylaşın</a>
						</li>
						<li class="nav-item">
							<a class="nav-link" data-toggle="tab" href="#yorumlar">Yorumlar</a>
						</li>
					</ul>
				
				<div class="tab-content">
					<div id="yorumyap" class="container tab-pane active">
						<form action="<?=base_url('home/yorum/')?>" method="post" class="was-validated bg-white p-5 contact-form"  enctype="multipart/form-data">
						  <div class="form-group">  
							<input required type="text" id="adi" name="adi" class="form-control form-control-lg" placeholder="Ad Soyad">
						  </div>
						  <div class="form-group">
							<textarea required name="mesaj" id="" cols="30" rows="7" class="form-control" placeholder="Memnuniyetinizi Yada Şikayetinizi Yazınız 😉"></textarea>
						  </div>
						  <div class="form-group">
							<input type="submit" onclick="gonder();" value="GÖNDER" class="btn btn-primary py-3 px-5">
						  </div>
						</form>
					</div>
				
				
					<div id="yorumlar" class="container tab-pane fade">
					<br>
					<?php
					foreach($yorum as $yr)
					{ ?>
						<div class="container" >
							<div class="row justify-content-center">
								<div class="product">
									<div class="card-header"><?=$yr->adi?></div>
										<div class="card-body">
												<div class="cart-text"><?=$yr->tarih?></div>
												<div class="cart-text"><?=$yr->mesaj?></div>
												
												
										</div>
								</div>
							</div>
						</div>
					<?php }?>
					</div>
				</div>
				
    	</div>
    </section>

   