<div id="left" >
                        <div class="media user-media bg-dark dker">
                            <div class="user-media-toggleHover">
                                <span class="fa fa-user"></span>
                            </div>
                            <div class="user-wrapper bg-dark">
                                <a class="user-link" href="">
                                    <img class="media-object img-thumbnail user-img" alt="User Picture" src="<?=base_url()?>/assets/images/home/logo.png">
                                    
                                </a>
                        
                                <div class="media-body">
                                    <h5 class="media-heading"><br>Hoşgeldiniz<br><?=$this->session->admin_session["adsoy"]?></h5>
                                    <ul class="list-unstyled user-info">
                                        <li><a href="">Admin</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <!-- #menu -->
                        <ul id="menu" class="bg-blue dker">
                                  <li class="nav-header">Menu</li>
                                  <li class="nav-divider"></li>
                                  <li class="">
                                    <a href="<?=base_url()?>admin/home">
                                      <i class=""></i><span class="link-title">&#127968; Anasayfa</span>
                                    </a>
                                  </li>
                                  <li class="">
                                    <a href="<?=base_url()?>admin/kullanicilar">
                                      <i class="icon icon-fort-awesome"></i>
                                      <span class="link-title">👨‍💻 Kullanıcılar</span>
                                      
                                    </a>
                                  </li>
                                  <li class="">
                                    <a href="<?=base_url()?>admin/musteriler">
                                      <i class=""></i>
                                      <span class="link-title">👩‍👩‍👦‍👦  Müşteriler</span>
                                    </a>
                                  </li>
								  <li class="">
                                    <a href="<?=base_url()?>admin/urunler">
                                      <i class=""></i>
                                      <span class="link-title">🍱 Ürünler</span>
                                    </a>
                                  </li>
                                  <li class="">
                                    <a href="<?=base_url()?>admin/kategoriler">
                                      <i class=""></i>
                                      <span class="link-title">🔱 Kategoriler</span>
                                    </a>
                                  </li>
                                  <li>
                                    <a href="<?=base_url()?>admin/siparisler">
                                      <i class=""></i>
                                      <span class="link-title">&#128176; Siparişler</span>
                                    </a>
                                  </li>
                                  <li>
                                    <a href="<?=base_url()?>admin/mesajlar">
                                      <i class=""></i>
                                      <span class="link-title">&#128140; İletişim Mesajları</span>  
									</a>
                                  </li>
								  <li>
                                    <a href="<?=base_url()?>admin/home/ayarlar">
                                      <i class=""></i>
                                      <span class="link-title">&#128296; Ayarlar</span>  
									</a>
                                  </li>
								  <li>
                                    <a href="">
                                      <i class=""></i>
                                      <span class="link-title"></span>  
									</a>
                                  </li>
								  <li>
                                    <a href="">
                                      <i class=""></i>
                                      <span class="link-title"></span>  
									</a>
                                  </li>
								  <li>
                                    <a href="">
                                      <i class=""></i>
                                      <span class="link-title"></span>  
									</a>
                                  </li>
								  <li>
                                    <a href="">
                                      <i class=""></i>
                                      <span class="link-title"></span>  
									</a>
                                  </li>
								  <li>
                                    <a href="">
                                      <i class=""></i>
                                      <span class="link-title"></span>  
									</a>
                                  </li>
								  <li>
                                    <a href="">
                                      <i class=""></i>
                                      <span class="link-title"></span>  
									</a>
                                  </li>
								  
								  
                        <!-- /#menu -->
                    </div>
                    <!-- /#left -->