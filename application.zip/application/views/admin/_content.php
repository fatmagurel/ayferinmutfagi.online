<div id="content">
                    <div class="outer">
                        <div class="inner bg-light lter">
                            &nbsp;
                        </div>
                        <!-- /.inner -->
                    </div>
                    <!-- /.outer -->
                </div>
                <!-- /#content -->