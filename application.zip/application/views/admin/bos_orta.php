<div id="content">
                    <div class="outer">
                        <div class="inner bg-light lter">
                            Ayarlar
                        </div>
                        <!-- /.inner -->
                    </div>
                    <!-- /.outer -->
                </div>
                <!-- /#content -->