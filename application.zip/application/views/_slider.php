
    <section id="home-section" class="hero">
		  <div class="home-slider owl-carousel">
	      <div class="slider-item " style="margin:auto; background-image: url(assets/images/iclikofte.jpg);">
	      	<div class="overlay"></div>
	        <div class="container">
	          <div class="row slider-text justify-content-center align-items-center" data-scrollax-parent="true">

	            <div class="col-md-12 ftco-animate text-center">
	              <h1 class="mb-2" style="font-family: Buxton Sketch; font-size:50px;">AYFER'İN MUTFAĞI</h1>
	            </div>

	          </div>
	        </div>
	      </div>

	      <div class="slider-item" style="margin: auto; background-image: url(assets/images/manti.jpg);">
	      	<div class="overlay"></div>
	        <div class="container">
	          <div class="row slider-text justify-content-center align-items-center" data-scrollax-parent="true">

	            <div class="col-sm-12 ftco-animate text-center">
	              <h1 class="mb-2" style="font-family: Buxton Sketch; font-size:50px;">El Yapımı Her Zaman Taze Ürünler</h1>
	            </div>

	          </div>
	        </div>
	      </div>
		  
		  <div class="slider-item" style="margin:auto;  background-image: url(assets/images/yaprak1.jpg);">
	      	<div class="overlay"></div>
	        <div class="container">
	          <div class="row slider-text justify-content-center align-items-center" data-scrollax-parent="true">

	            <div class="col-sm-12 ftco-animate text-center">
	              <h1 class="mb-2" style="font-family: Buxton Sketch; font-size:50px;">En Hızlı Teslimat</h1>
	            </div>

	          </div>
	        </div>
	      </div>
	    </div>
    </section>